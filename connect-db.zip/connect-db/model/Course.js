class Course {
  constructor(courseId, courseName, accountId) {
    this.courseId = courseId;
    this.courseName = courseName;
    this.accountId = accountId;
  }
}

module.exports = Course;

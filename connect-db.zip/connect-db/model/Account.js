class Account {
  constructor(accountId, username, password, name, email) {
    this.accountId = accountId;
    this.username = username;
    this.password = password;
    this.name = name;
    this.email = email;
  }
}
module.exports = Account;

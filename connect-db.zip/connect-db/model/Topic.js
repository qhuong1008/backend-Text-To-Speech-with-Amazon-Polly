class Topic {
  constructor(topicId, topicName, courseId) {
    this.topicId = topicId;
    this.topicName = topicName;
    this.courseId = courseId;
  }
}
module.exports = Topic;

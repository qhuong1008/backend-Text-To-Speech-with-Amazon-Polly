class Word {
  constructor(wordId, eng, pronounce, viet, topicId) {
    this.wordId = wordId;
    this.eng = eng;
    this.pronounce = pronounce;
    this.viet = viet;
    this.topicId = topicId;
  }
}
module.exports = Word;
